// Risk Fusion Agent Hook
import { useState, useEffect, useCallback, useRef } from 'react';
import type { RiskScore, RiskLevel, RiskFactors, EnvironmentalData, SatelliteData } from '@/types';

// Risk level thresholds
const RISK_THRESHOLDS = {
  low: 0.4,
  moderate: 0.65,
  high: 0.85,
  critical: 1.0,
};

// Determine risk level from score
const getRiskLevel = (score: number): RiskLevel => {
  if (score <= RISK_THRESHOLDS.low) return 'low';
  if (score <= RISK_THRESHOLDS.moderate) return 'moderate';
  if (score <= RISK_THRESHOLDS.high) return 'high';
  return 'critical';
};

// Get risk color
export const getRiskColor = (level: RiskLevel): string => {
  switch (level) {
    case 'low': return '#22c55e'; // green-500
    case 'moderate': return '#eab308'; // yellow-500
    case 'high': return '#f97316'; // orange-500
    case 'critical': return '#ef4444'; // red-500
    default: return '#22c55e';
  }
};

// Get risk gradient
export const getRiskGradient = (level: RiskLevel): string => {
  switch (level) {
    case 'low': return 'from-green-500 to-emerald-400';
    case 'moderate': return 'from-yellow-500 to-amber-400';
    case 'high': return 'from-orange-500 to-red-400';
    case 'critical': return 'from-red-600 to-rose-500';
    default: return 'from-green-500 to-emerald-400';
  }
};

export const useRiskFusion = (
  environmentalData: EnvironmentalData | null,
  satelliteData: SatelliteData | null,
  distanceToCoast: number | null
) => {
  const [riskScore, setRiskScore] = useState<RiskScore | null>(null);
  const [riskHistory, setRiskHistory] = useState<RiskScore[]>([]);
  const [isComputing, setIsComputing] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Compute risk score based on all factors
  const computeRiskScore = useCallback(() => {
    if (!environmentalData) return null;

    setIsComputing(true);

    // Calculate individual risk factors (0-1 scale)
    const shorelineDeviation = Math.min(Math.abs(satelliteData?.deviation || 0) / 200, 1);
    const stormIndex = Math.min(environmentalData.stormIndex / 3, 1);
    const environmentalAnomaly = Math.min(
      (environmentalData.waveHeight / 6 + environmentalData.windSpeed / 50 + environmentalData.tideAnomaly / 3) / 3,
      1
    );
    const infrastructureDensity = 0.65; // Simulated
    const humanImpactIndex = 0.58; // Simulated
    const proximityToCoast = distanceToCoast !== null ? Math.max(0, 1 - distanceToCoast / 10000) : 0.5;

    const factors: RiskFactors = {
      shorelineDeviation,
      stormIndex,
      environmentalAnomaly,
      infrastructureDensity,
      humanImpactIndex,
      proximityToCoast,
    };

    // Weighted risk score calculation
    const weights = {
      shorelineDeviation: 0.25,
      stormIndex: 0.25,
      environmentalAnomaly: 0.20,
      infrastructureDensity: 0.10,
      humanImpactIndex: 0.10,
      proximityToCoast: 0.10,
    };

    const score = Math.min(
      Object.entries(factors).reduce((acc, [key, value]) => {
        return acc + value * weights[key as keyof typeof weights];
      }, 0),
      1
    );

    const newRiskScore: RiskScore = {
      score: Math.round(score * 1000) / 1000,
      level: getRiskLevel(score),
      timestamp: Date.now(),
      factors,
    };

    setRiskScore(newRiskScore);
    setRiskHistory((prev) => [...prev.slice(-49), newRiskScore]);
    setIsComputing(false);

    return newRiskScore;
  }, [environmentalData, satelliteData, distanceToCoast]);

  // Start auto-computation
  const startAutoCompute = useCallback((interval: number = 60000) => {
    if (intervalRef.current) return;
    
    // Compute immediately
    computeRiskScore();
    
    // Then set interval
    intervalRef.current = setInterval(() => {
      computeRiskScore();
    }, interval);
  }, [computeRiskScore]);

  // Stop auto-computation
  const stopAutoCompute = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Get risk trend (increasing, decreasing, stable)
  const getRiskTrend = useCallback(() => {
    if (riskHistory.length < 3) return 'stable';
    
    const recent = riskHistory.slice(-5);
    const avgRecent = recent.reduce((acc, r) => acc + r.score, 0) / recent.length;
    const avgPrevious = riskHistory.slice(-10, -5).reduce((acc, r) => acc + r.score, 0) / 5;
    
    const diff = avgRecent - avgPrevious;
    if (diff > 0.05) return 'increasing';
    if (diff < -0.05) return 'decreasing';
    return 'stable';
  }, [riskHistory]);

  // Trigger immediate computation when data changes
  useEffect(() => {
    if (environmentalData) {
      computeRiskScore();
    }
  }, [environmentalData, computeRiskScore]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    riskScore,
    riskHistory,
    isComputing,
    computeRiskScore,
    startAutoCompute,
    stopAutoCompute,
    getRiskTrend,
    thresholds: RISK_THRESHOLDS,
  };
};
