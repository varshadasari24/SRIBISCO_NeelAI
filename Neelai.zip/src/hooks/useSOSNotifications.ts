// SOS Notification System Hook
import { useState, useEffect, useCallback, useRef } from 'react';
import type { SOSAlert, RiskLevel, UserLocation, NearbyDevice } from '@/types';
import { haversineDistance } from './useGeoIntelligence';

// SOS message templates
const SOS_TEMPLATES: Record<string, Record<string, string>> = {
  flood: {
    critical: '🚨 CRITICAL FLOOD ALERT: Immediate evacuation required. Move to higher ground. Your location is in a flood-prone zone.',
    high: '⚠️ HIGH FLOOD RISK: Prepare for evacuation. Monitor water levels. Stay alert for updates.',
    moderate: 'ℹ️ FLOOD WATCH: Potential flooding in your area. Stay informed and prepare emergency kit.',
    low: 'ℹ️ FLOOD ADVISORY: Low flood risk. Stay informed and monitor conditions.',
  },
  erosion: {
    critical: '🚨 COASTAL EROSION EMERGENCY: Shoreline collapse imminent. Evacuate immediately to safe distance.',
    high: '⚠️ COASTAL EROSION WARNING: Rapid shoreline retreat detected. Avoid coastal areas.',
    moderate: 'ℹ️ EROSION ALERT: Unstable shoreline conditions. Exercise caution near water.',
    low: 'ℹ️ EROSION ADVISORY: Minor shoreline changes. Normal caution advised.',
  },
  storm: {
    critical: '🚨 SEVERE STORM WARNING: Extreme weather conditions. Seek shelter immediately. Do not venture outside.',
    high: '⚠️ STORM ALERT: High winds and waves expected. Secure loose objects. Stay indoors.',
    moderate: 'ℹ️ WEATHER WATCH: Storm conditions developing. Monitor local forecasts.',
    low: 'ℹ️ WEATHER ADVISORY: Calm conditions. No immediate storm threat.',
  },
};

// Simulated stakeholders database
const STAKEHOLDERS = [
  { id: 'sdma', name: 'State Disaster Management Authority', phone: '+91-471-2331500', type: 'authority' },
  { id: 'coastguard', name: 'Indian Coast Guard - Kerala', phone: '+91-484-2666600', type: 'rescue' },
  { id: 'fire', name: 'Kerala Fire & Rescue', phone: '101', type: 'emergency' },
  { id: 'police', name: 'Coastal Police Station', phone: '100', type: 'emergency' },
  { id: 'municipality', name: 'Local Municipality', phone: '+91-477-1234567', type: 'local' },
];

export const useSOSNotifications = () => {
  const [alerts, setAlerts] = useState<SOSAlert[]>([]);
  const [activeNotifications, setActiveNotifications] = useState<SOSAlert[]>([]);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const [nearbyDevices, setNearbyDevices] = useState<NearbyDevice[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Request notification permission
  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    const permission = await Notification.requestPermission();
    setNotificationPermission(permission);
    return permission === 'granted';
  }, []);

  // Initialize audio for alerts
  useEffect(() => {
    // Create audio context for beep sound
    audioRef.current = new Audio();
    audioRef.current.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmFgU7k9n1unEiBC13yO/eizEIHWq+8+OWT';
  }, []);

  // Play alert sound
  const playAlertSound = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.play().catch(() => {
        // Ignore audio play errors
      });
    }
  }, []);

  // Send browser notification
  const sendBrowserNotification = useCallback((title: string, body: string, tag: string) => {
    if (notificationPermission === 'granted') {
      new Notification(title, {
        body,
        tag,
        icon: '/logos/dm.png',
        badge: '/logos/dm.png',
        requireInteraction: true,
        silent: false,
      });
    }
  }, [notificationPermission]);

  // Trigger SOS alert
  const triggerSOS = useCallback((
    location: UserLocation,
    type: 'flood' | 'erosion' | 'storm',
    severity: RiskLevel,
    radius: number = 500
  ) => {
    const message = SOS_TEMPLATES[type][severity];
    
    const newAlert: SOSAlert = {
      id: `sos-${Date.now()}`,
      location,
      type,
      severity,
      timestamp: Date.now(),
      message,
      radius,
      recipients: Math.floor(Math.random() * 50) + 20, // Simulated recipients
    };

    setAlerts((prev) => [newAlert, ...prev]);
    setActiveNotifications((prev) => [newAlert, ...prev]);

    // Play alert sound
    playAlertSound();

    // Send browser notification
    sendBrowserNotification(
      `NEELAI ${type.toUpperCase()} ALERT`,
      message,
      newAlert.id
    );

    // Simulate finding nearby devices
    const devices: NearbyDevice[] = [];
    for (let i = 0; i < 12; i++) {
      const angle = (Math.PI * 2 * i) / 12;
      const dist = Math.random() * radius;
      devices.push({
        id: `device-${Date.now()}-${i}`,
        location: [
          location.lat + (dist / 111000) * Math.cos(angle),
          location.lng + (dist / (111000 * Math.cos(location.lat * Math.PI / 180))) * Math.sin(angle),
        ],
        distance: Math.round(dist),
        lastSeen: Date.now(),
      });
    }
    setNearbyDevices(devices);

    // Auto-dismiss after 30 seconds for moderate, 60 for high, manual for critical
    const dismissTime = severity === 'moderate' ? 30000 : severity === 'high' ? 60000 : null;
    if (dismissTime) {
      setTimeout(() => {
        dismissAlert(newAlert.id);
      }, dismissTime);
    }

    return newAlert;
  }, [playAlertSound, sendBrowserNotification]);

  // Dismiss alert
  const dismissAlert = useCallback((alertId: string) => {
    setActiveNotifications((prev) => prev.filter((a) => a.id !== alertId));
  }, []);

  // Clear all notifications
  const clearAllNotifications = useCallback(() => {
    setActiveNotifications([]);
  }, []);

  // Send notification to stakeholders
  const notifyStakeholders = useCallback((_alert: SOSAlert) => {
    console.log('Notifying stakeholders:', STAKEHOLDERS);
    // In real implementation, this would send SMS/emails to stakeholders
    return STAKEHOLDERS;
  }, []);

  // Check if location is within alert radius
  const isWithinAlertRadius = useCallback((
    userLocation: [number, number],
    alertLocation: [number, number],
    radius: number
  ): boolean => {
    const distance = haversineDistance(
      userLocation[0],
      userLocation[1],
      alertLocation[0],
      alertLocation[1]
    );
    return distance <= radius;
  }, []);

  // Get active alerts for a location
  const getActiveAlertsForLocation = useCallback((location: [number, number]) => {
    return activeNotifications.filter((alert) =>
      isWithinAlertRadius(location, [alert.location.lat, alert.location.lng], alert.radius)
    );
  }, [activeNotifications, isWithinAlertRadius]);

  // Auto-request permission on mount
  useEffect(() => {
    requestPermission();
  }, [requestPermission]);

  return {
    alerts,
    activeNotifications,
    nearbyDevices,
    notificationPermission,
    stakeholders: STAKEHOLDERS,
    triggerSOS,
    dismissAlert,
    clearAllNotifications,
    notifyStakeholders,
    requestPermission,
    isWithinAlertRadius,
    getActiveAlertsForLocation,
  };
};
