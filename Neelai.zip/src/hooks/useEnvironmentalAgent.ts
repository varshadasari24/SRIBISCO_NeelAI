// Environmental Data Agent Hook
import { useState, useEffect, useCallback, useRef } from 'react';
import type { EnvironmentalData } from '@/types';

// Simulated IMD/INCOIS data for Kerala coast
const generateEnvironmentalData = (): EnvironmentalData => {
  const baseWaveHeight = 2.5;
  const baseWindSpeed = 18;
  const baseTide = 1.2;
  const basePressure = 1013;
  const baseRainfall = 15;

  // Add some randomness to simulate real-time changes
  const waveHeight = baseWaveHeight + (Math.random() - 0.5) * 2;
  const windSpeed = baseWindSpeed + (Math.random() - 0.5) * 10;
  const tideAnomaly = baseTide + (Math.random() - 0.5) * 0.8;
  const pressure = basePressure + (Math.random() - 0.5) * 15;
  const rainfall = Math.max(0, baseRainfall + (Math.random() - 0.5) * 30);

  // Storm Index calculation: (wave_height × wind_speed × tide_anomaly) / normalization_factor
  const normalizationFactor = 100;
  const stormIndex = (waveHeight * windSpeed * tideAnomaly) / normalizationFactor;

  return {
    waveHeight: Math.round(waveHeight * 10) / 10,
    windSpeed: Math.round(windSpeed * 10) / 10,
    tideAnomaly: Math.round(tideAnomaly * 100) / 100,
    pressure: Math.round(pressure),
    rainfall: Math.round(rainfall * 10) / 10,
    stormIndex: Math.round(stormIndex * 100) / 100,
    timestamp: Date.now(),
  };
};

// Historical environmental data for charts
const generateHistoricalData = (hours: number = 24): EnvironmentalData[] => {
  const data: EnvironmentalData[] = [];
  const now = Date.now();
  
  for (let i = hours; i >= 0; i--) {
    const timestamp = now - i * 3600000;
    const baseWaveHeight = 2.5 + Math.sin(i * 0.3) * 1.5;
    const baseWindSpeed = 18 + Math.cos(i * 0.2) * 8;
    const baseTide = 1.2 + Math.sin(i * 0.5) * 0.5;
    
    data.push({
      waveHeight: Math.round(baseWaveHeight * 10) / 10,
      windSpeed: Math.round(baseWindSpeed * 10) / 10,
      tideAnomaly: Math.round(baseTide * 100) / 100,
      pressure: Math.round(1013 + Math.sin(i * 0.1) * 10),
      rainfall: Math.round(Math.max(0, 15 + Math.sin(i * 0.4) * 20) * 10) / 10,
      stormIndex: Math.round((baseWaveHeight * baseWindSpeed * baseTide) / 100 * 100) / 100,
      timestamp,
    });
  }
  
  return data;
};

export const useEnvironmentalAgent = () => {
  const [currentData, setCurrentData] = useState<EnvironmentalData>(generateEnvironmentalData());
  const [historicalData, setHistoricalData] = useState<EnvironmentalData[]>(generateHistoricalData());
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<number>(Date.now());
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Fetch latest environmental data (simulated API call)
  const fetchEnvironmentalData = useCallback(async () => {
    setIsLoading(true);
    
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));
    
    const newData = generateEnvironmentalData();
    setCurrentData(newData);
    setHistoricalData((prev) => [...prev.slice(1), newData]);
    setLastUpdate(Date.now());
    setIsLoading(false);
    
    return newData;
  }, []);

  // Start auto-polling every 5 minutes (simulated: every 10 seconds for demo)
  const startPolling = useCallback(() => {
    if (intervalRef.current) return;
    
    intervalRef.current = setInterval(() => {
      fetchEnvironmentalData();
    }, 10000); // 10 seconds for demo
  }, [fetchEnvironmentalData]);

  // Stop auto-polling
  const stopPolling = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Detect anomaly spikes
  const detectAnomaly = useCallback(() => {
    if (!currentData) return false;
    
    const waveAnomaly = currentData.waveHeight > 4.5;
    const windAnomaly = currentData.windSpeed > 35;
    const tideAnomaly = currentData.tideAnomaly > 2.0;
    const pressureAnomaly = currentData.pressure < 995;
    
    return waveAnomaly || windAnomaly || tideAnomaly || pressureAnomaly;
  }, [currentData]);

  // Get storm surge alert level
  const getStormAlertLevel = useCallback(() => {
    if (!currentData) return 'normal';
    
    const stormIndex = currentData.stormIndex;
    if (stormIndex > 2.5) return 'critical';
    if (stormIndex > 1.5) return 'high';
    if (stormIndex > 0.8) return 'moderate';
    return 'low';
  }, [currentData]);

  useEffect(() => {
    // Initial fetch
    fetchEnvironmentalData();
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [fetchEnvironmentalData]);

  return {
    currentData,
    historicalData,
    isLoading,
    lastUpdate,
    fetchEnvironmentalData,
    startPolling,
    stopPolling,
    detectAnomaly,
    getStormAlertLevel,
  };
};
