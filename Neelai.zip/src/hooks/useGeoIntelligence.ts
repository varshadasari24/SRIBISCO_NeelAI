// Geo-Intelligence Agent Hook
import { useState, useEffect, useCallback, useRef } from 'react';
import type { UserLocation, GeoFence } from '@/types';

// Kerala coastal districts with risk zones
const KERALA_GEOFENCES: GeoFence[] = [
  { id: 'alappuzha-1', center: [9.49, 76.33], radius: 2000, riskLevel: 'high', type: 'erosion' },
  { id: 'alappuzha-2', center: [9.52, 76.35], radius: 1500, riskLevel: 'critical', type: 'flood' },
  { id: 'ernakulam-1', center: [9.98, 76.27], radius: 2500, riskLevel: 'moderate', type: 'erosion' },
  { id: 'ernakulam-2', center: [10.02, 76.30], radius: 1800, riskLevel: 'high', type: 'storm' },
  { id: 'kollam-1', center: [8.88, 76.60], radius: 2200, riskLevel: 'moderate', type: 'erosion' },
  { id: 'kozhikode-1', center: [11.25, 75.77], radius: 3000, riskLevel: 'high', type: 'erosion' },
  { id: 'kannur-1', center: [11.87, 75.37], radius: 2000, riskLevel: 'moderate', type: 'flood' },
  { id: 'thrissur-1', center: [10.52, 76.22], radius: 2500, riskLevel: 'low', type: 'erosion' },
];

// Haversine distance calculation in meters
export const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371000; // Earth's radius in meters
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export const useGeoIntelligence = () => {
  const [location, setLocation] = useState<UserLocation | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [nearestGeofence, setNearestGeofence] = useState<GeoFence | null>(null);
  const [distanceToCoast, setDistanceToCoast] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const watchIdRef = useRef<ReturnType<typeof navigator.geolocation.watchPosition> | null>(null);

  // Calculate distance to nearest geofence
  const calculateNearestGeofence = useCallback((lat: number, lng: number) => {
    let nearest: GeoFence | null = null;
    let minDistance = Infinity;

    KERALA_GEOFENCES.forEach((fence) => {
      const dist = haversineDistance(lat, lng, fence.center[0], fence.center[1]);
      if (dist < minDistance) {
        minDistance = dist;
        nearest = fence;
      }
    });

    setNearestGeofence(nearest);
    setDistanceToCoast(minDistance);
    return { nearest, distance: minDistance };
  }, []);

  // Start location tracking
  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser');
      return;
    }

    setIsTracking(true);
    setError(null);

    // Get initial position
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const loc = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          timestamp: Date.now(),
          accuracy: position.coords.accuracy,
        };
        setLocation(loc);
        calculateNearestGeofence(loc.lat, loc.lng);
      },
      (err) => {
        setError(`Error getting location: ${err.message}`);
        setIsTracking(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );

    // Watch position updates every 60 seconds
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const loc = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          timestamp: Date.now(),
          accuracy: position.coords.accuracy,
        };
        setLocation(loc);
        calculateNearestGeofence(loc.lat, loc.lng);
      },
      (err) => {
        setError(`Location error: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }, [calculateNearestGeofence]);

  // Stop location tracking
  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
  }, []);

  // Check if user is inside a geofence
  const isInsideGeofence = useCallback((radius: number = 500): boolean => {
    if (!location || !nearestGeofence) return false;
    const dist = haversineDistance(
      location.lat,
      location.lng,
      nearestGeofence.center[0],
      nearestGeofence.center[1]
    );
    return dist <= radius;
  }, [location, nearestGeofence]);

  // Get nearby devices within 500m radius
  const getNearbyDevices = useCallback((centerLat: number, centerLng: number, radius: number = 500) => {
    // Simulate nearby devices for demo
    const devices = [];
    for (let i = 0; i < 8; i++) {
      const angle = (Math.PI * 2 * i) / 8;
      const dist = Math.random() * radius;
      devices.push({
        id: `device-${i}`,
        location: [
          centerLat + (dist / 111000) * Math.cos(angle),
          centerLng + (dist / (111000 * Math.cos(centerLat * Math.PI / 180))) * Math.sin(angle),
        ] as [number, number],
        distance: Math.round(dist),
        lastSeen: Date.now() - Math.random() * 300000,
      });
    }
    return devices;
  }, []);

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  return {
    location,
    isTracking,
    nearestGeofence,
    distanceToCoast,
    error,
    startTracking,
    stopTracking,
    isInsideGeofence,
    getNearbyDevices,
    geofences: KERALA_GEOFENCES,
  };
};
