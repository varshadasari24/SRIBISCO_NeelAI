import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Map as MapIcon, 
  BarChart3, 
  Activity, 
  Satellite, 
  Bell,
  Menu,
  X,
  ChevronRight,
  Shield,
  Waves,
  Wind
} from 'lucide-react';
import { LogoHeader } from '@/components/LogoHeader';
import { KeralaMap } from '@/components/KeralaMap';
import { RiskGauge } from '@/components/RiskGauge';
import { EnvironmentalPanel } from '@/components/EnvironmentalPanel';
import { SOSPanel } from '@/components/SOSPanel';
import { ErosionTrend } from '@/components/ErosionTrend';
import { SatelliteMetadata } from '@/components/SatelliteMetadata';
import { AgentStatus } from '@/components/AgentStatus';
import { useGeoIntelligence } from '@/hooks/useGeoIntelligence';
import { useSatelliteAgent } from '@/hooks/useSatelliteAgent';
import { useEnvironmentalAgent } from '@/hooks/useEnvironmentalAgent';
import { useRiskFusion } from '@/hooks/useRiskFusion';
import { useSOSNotifications } from '@/hooks/useSOSNotifications';
import type { RiskLevel } from '@/types';
import './App.css';

// SOS Notification Toast Component
const SOSNotification = ({ 
  alert, 
  onDismiss 
}: { 
  alert: { id: string; message: string; type: string; severity: RiskLevel };
  onDismiss: () => void;
}) => {
  const getBgColor = () => {
    switch (alert.severity) {
      case 'critical': return 'from-red-600 to-red-500';
      case 'high': return 'from-orange-600 to-orange-500';
      case 'moderate': return 'from-yellow-600 to-yellow-500';
      default: return 'from-green-600 to-green-500';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 100, scale: 0.9 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 100, scale: 0.9 }}
      className={`fixed top-24 right-4 z-50 max-w-sm bg-gradient-to-r ${getBgColor()} text-white rounded-xl shadow-2xl border border-white/20 overflow-hidden`}
    >
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
            <Bell className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold text-lg uppercase tracking-wider">
              {alert.type} Alert
            </div>
            <p className="text-sm text-white/90 mt-1 leading-relaxed">
              {alert.message}
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="text-xs bg-white/20 px-2 py-1 rounded-full">
                500m Radius
              </span>
              <span className="text-xs bg-white/20 px-2 py-1 rounded-full capitalize">
                {alert.severity}
              </span>
            </div>
          </div>
          <button
            onClick={onDismiss}
            className="text-white/70 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="h-1 bg-white/30">
        <motion.div
          className="h-full bg-white"
          initial={{ width: '100%' }}
          animate={{ width: '0%' }}
          transition={{ duration: 30, ease: 'linear' }}
        />
      </div>
    </motion.div>
  );
};

function App() {
  // Sidebar state
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Map layer toggles
  const [showSatellite, setShowSatellite] = useState(false);
  const [showRiskHeatmap, setShowRiskHeatmap] = useState(true);
  const [showShoreline, setShowShoreline] = useState(true);

  // Initialize all agents
  const geoAgent = useGeoIntelligence();
  const satelliteAgent = useSatelliteAgent();
  const environmentalAgent = useEnvironmentalAgent();
  const riskFusion = useRiskFusion(
    environmentalAgent.currentData,
    satelliteAgent.latestScene,
    geoAgent.distanceToCoast
  );
  const sosNotifications = useSOSNotifications();

  // Auto-trigger SOS when risk is critical
  useEffect(() => {
    if (riskFusion.riskScore?.level === 'critical' && geoAgent.location) {
      const alert = sosNotifications.triggerSOS(
        geoAgent.location,
        'flood',
        'critical',
        500
      );
      
      // Notify stakeholders
      sosNotifications.notifyStakeholders(alert);
    }
  }, [riskFusion.riskScore?.level, geoAgent.location]);

  // Start all agents on mount
  useEffect(() => {
    geoAgent.startTracking();
    environmentalAgent.startPolling();
    satelliteAgent.startAutoFetch();
    riskFusion.startAutoCompute(60000);

    return () => {
      geoAgent.stopTracking();
      environmentalAgent.stopPolling();
      satelliteAgent.stopAutoFetch();
      riskFusion.stopAutoCompute();
    };
  }, []);

  // Handle manual SOS trigger
  const handleTriggerSOS = useCallback((type: 'flood' | 'erosion' | 'storm', severity: RiskLevel) => {
    if (geoAgent.location) {
      const alert = sosNotifications.triggerSOS(geoAgent.location, type, severity, 500);
      sosNotifications.notifyStakeholders(alert);
    }
  }, [geoAgent.location, sosNotifications]);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <Activity className="w-5 h-5" /> },
    { id: 'map', label: 'Live Map', icon: <MapIcon className="w-5 h-5" /> },
    { id: 'satellite', label: 'Satellite Data', icon: <Satellite className="w-5 h-5" /> },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'alerts', label: 'SOS Alerts', icon: <Bell className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950 text-white overflow-x-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {/* Ocean Waves Animation */}
        <div className="absolute bottom-0 left-0 right-0 h-64 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 1440 320" preserveAspectRatio="none">
            <motion.path
              fill="url(#waveGradient)"
              d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
              animate={{
                d: [
                  "M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z",
                  "M0,128L48,154.7C96,181,192,235,288,234.7C384,235,480,181,576,181.3C672,181,768,235,864,250.7C960,267,1056,245,1152,229.3C1248,213,1344,203,1392,197.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z",
                ]
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut"
              }}
            />
            <defs>
              <linearGradient id="waveGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#0891b2" stopOpacity="0.8" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.6, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* SOS Notifications */}
      <AnimatePresence>
        {sosNotifications.activeNotifications.slice(0, 3).map((alert) => (
          <SOSNotification
            key={alert.id}
            alert={alert}
            onDismiss={() => sosNotifications.dismissAlert(alert.id)}
          />
        ))}
      </AnimatePresence>

      {/* Logo Header */}
      <LogoHeader />

      {/* Mobile Menu Button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 bg-slate-900/80 backdrop-blur-md rounded-lg border border-cyan-500/30"
      >
        {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: sidebarOpen ? 0 : -300 }}
        className={`fixed left-0 top-0 bottom-0 w-64 bg-slate-900/95 backdrop-blur-xl border-r border-cyan-500/30 z-40 lg:translate-x-0 transition-transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-6 pt-24">
          <nav className="space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/30 text-cyan-400 border border-cyan-500/50'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                }`}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
                {activeTab === item.id && (
                  <ChevronRight className="w-4 h-4 ml-auto" />
                )}
              </button>
            ))}
          </nav>

          {/* Map Layer Controls */}
          <div className="mt-8 pt-8 border-t border-slate-700">
            <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-4">
              Map Layers
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showSatellite}
                  onChange={(e) => setShowSatellite(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-sm text-slate-400">Satellite Imagery</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showRiskHeatmap}
                  onChange={(e) => setShowRiskHeatmap(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-sm text-slate-400">Risk Heatmap</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showShoreline}
                  onChange={(e) => setShowShoreline(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-600 bg-slate-800 text-cyan-500 focus:ring-cyan-500"
                />
                <span className="text-sm text-slate-400">Shoreline Vector</span>
              </label>
            </div>
          </div>

          {/* System Status */}
          <div className="mt-8 pt-8 border-t border-slate-700">
            <div className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-4">
              System Status
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">GPS Tracking</span>
                <span className={geoAgent.isTracking ? 'text-green-400' : 'text-red-400'}>
                  {geoAgent.isTracking ? 'Active' : 'Inactive'}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Data Stream</span>
                <span className="text-green-400">Live</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Risk Engine</span>
                <span className="text-green-400">Running</span>
              </div>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="lg:ml-64 p-6 pt-6">
        {/* Welcome Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 p-6 bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 rounded-xl border border-cyan-500/30"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-cyan-500/30 flex items-center justify-center">
              <Shield className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">
                NEELAI Coastal Intelligence System
              </h2>
              <p className="text-slate-400 text-sm">
                Monitoring Kerala coastline • Real-time risk assessment • 500m SOS radius
              </p>
            </div>
            <div className="ml-auto flex items-center gap-4">
              <div className="text-right">
                <div className="text-xs text-slate-400">Target Region</div>
                <div className="text-sm font-semibold text-cyan-400">Alappuzha + Ernakulam</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400">Active Alerts</div>
                <div className="text-sm font-semibold text-red-400">
                  {sosNotifications.activeNotifications.length}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map - Takes 2 columns */}
          <div className="lg:col-span-2 h-[500px] lg:h-[600px]">
            <KeralaMap
              userLocation={geoAgent.location}
              geofences={geoAgent.geofences}
              activeAlerts={sosNotifications.activeNotifications}
              nearbyDevices={sosNotifications.nearbyDevices}
              showSatellite={showSatellite}
              showRiskHeatmap={showRiskHeatmap}
              showShoreline={showShoreline}
            />
          </div>

          {/* Right Panel - Risk & SOS */}
          <div className="space-y-6">
            <RiskGauge 
              riskScore={riskFusion.riskScore} 
              riskTrend={riskFusion.getRiskTrend()} 
            />
            <SOSPanel
              activeAlerts={sosNotifications.activeNotifications}
              nearbyDevices={sosNotifications.nearbyDevices}
              onTriggerSOS={handleTriggerSOS}
              onDismissAlert={sosNotifications.dismissAlert}
              onClearAll={sosNotifications.clearAllNotifications}
              notificationPermission={sosNotifications.notificationPermission}
              onRequestPermission={sosNotifications.requestPermission}
            />
          </div>
        </div>

        {/* Bottom Panel - Environmental, Erosion, Satellite, Agents */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mt-6">
          <EnvironmentalPanel
            currentData={environmentalAgent.currentData}
            historicalData={environmentalAgent.historicalData}
            isLoading={environmentalAgent.isLoading}
          />
          <ErosionTrend
            historicalData={satelliteAgent.historicalData}
            futurePredictions={satelliteAgent.futurePredictions}
            epr={satelliteAgent.erosionTrend.epr}
            lrr={satelliteAgent.erosionTrend.lrr}
            fractalDimension={satelliteAgent.erosionTrend.fractalDimension}
          />
          <SatelliteMetadata
            satelliteData={satelliteAgent.satelliteData}
            latestScene={satelliteAgent.latestScene}
            isProcessing={satelliteAgent.isProcessing}
            onProcessMNDWI={satelliteAgent.processMNDWI}
            onFetchLatest={satelliteAgent.fetchLatestScene}
          />
          <AgentStatus />
        </div>

        {/* Footer */}
        <footer className="mt-12 py-6 border-t border-slate-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-slate-500">
              <span className="text-cyan-400 font-semibold">NEELAI</span> — Neural Environmental & Erosion Learning AI
            </div>
            <div className="flex items-center gap-6 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <Waves className="w-3 h-3" />
                IMD Data
              </span>
              <span className="flex items-center gap-1">
                <Wind className="w-3 h-3" />
                INCOIS Feed
              </span>
              <span className="flex items-center gap-1">
                <Satellite className="w-3 h-3" />
                Sentinel-2
              </span>
            </div>
            <div className="text-xs text-slate-600">
              © 2025 NEELAI | Kerala State Disaster Management Authority
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}

export default App;
