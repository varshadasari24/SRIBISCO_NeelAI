// NEELAI - Type Definitions

export interface UserLocation {
  lat: number;
  lng: number;
  timestamp: number;
  accuracy?: number;
}

export interface GeoFence {
  id: string;
  center: [number, number];
  radius: number; // in meters
  riskLevel: RiskLevel;
  type: 'erosion' | 'flood' | 'storm';
}

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface RiskScore {
  score: number; // 0-1
  level: RiskLevel;
  timestamp: number;
  factors: RiskFactors;
}

export interface RiskFactors {
  shorelineDeviation: number;
  stormIndex: number;
  environmentalAnomaly: number;
  infrastructureDensity: number;
  humanImpactIndex: number;
  proximityToCoast: number;
}

export interface SatelliteData {
  sceneId: string;
  timestamp: number;
  cloudCoverage: number;
  resolution: number;
  shorelineVector: GeoJSON.Feature;
  deviation: number;
  erosionIndex: number;
}

export interface EnvironmentalData {
  waveHeight: number;
  windSpeed: number;
  tideAnomaly: number;
  pressure: number;
  rainfall: number;
  stormIndex: number;
  timestamp: number;
}

export interface SOSAlert {
  id: string;
  location: UserLocation;
  type: 'flood' | 'erosion' | 'storm';
  severity: RiskLevel;
  timestamp: number;
  message: string;
  radius: number;
  recipients: number;
}

export interface Incident {
  id: string;
  type: 'flood' | 'erosion' | 'storm';
  location: [number, number];
  timestamp: number;
  riskScore: number;
  status: 'active' | 'resolved';
}

export interface ShorelinePoint {
  lat: number;
  lng: number;
  year: number;
  deviation: number;
}

export interface ErosionTrend {
  epr: number; // End Point Rate
  lrr: number; // Linear Regression Rate
  fractalDimension: number;
  historicalData: ShorelinePoint[];
}

export interface AgentStatus {
  name: string;
  status: 'active' | 'inactive' | 'error';
  lastUpdate: number;
  interval: number;
}

export interface NearbyDevice {
  id: string;
  location: [number, number];
  distance: number;
  lastSeen: number;
}
