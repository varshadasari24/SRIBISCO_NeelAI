import { motion } from 'framer-motion';
import { Waves, Wind, Droplets, Gauge, CloudRain, Activity } from 'lucide-react';
import type { EnvironmentalData } from '@/types';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Legend
} from 'recharts';

interface EnvironmentalPanelProps {
  currentData: EnvironmentalData | null;
  historicalData: EnvironmentalData[];
  isLoading: boolean;
}

export const EnvironmentalPanel = ({ currentData, historicalData, isLoading }: EnvironmentalPanelProps) => {
  const getStormAlertColor = (index: number) => {
    if (index > 2.5) return 'text-red-500';
    if (index > 1.5) return 'text-orange-500';
    if (index > 0.8) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getStormAlertBg = (index: number) => {
    if (index > 2.5) return 'bg-red-500/20 border-red-500/50';
    if (index > 1.5) return 'bg-orange-500/20 border-orange-500/50';
    if (index > 0.8) return 'bg-yellow-500/20 border-yellow-500/50';
    return 'bg-green-500/20 border-green-500/50';
  };

  const chartData = historicalData.map((d) => ({
    time: new Date(d.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    waveHeight: d.waveHeight,
    windSpeed: d.windSpeed,
    stormIndex: d.stormIndex,
    tideAnomaly: d.tideAnomaly,
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Environmental Data
        </h3>
        {isLoading && (
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-cyan-400">Updating...</span>
          </div>
        )}
      </div>

      {/* Current Metrics Grid */}
      {currentData && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-1">
              <Waves className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-slate-400">Wave Height</span>
            </div>
            <div className="text-xl font-bold text-white">{currentData.waveHeight}m</div>
          </div>
          
          <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-1">
              <Wind className="w-4 h-4 text-cyan-400" />
              <span className="text-xs text-slate-400">Wind Speed</span>
            </div>
            <div className="text-xl font-bold text-white">{currentData.windSpeed} km/h</div>
          </div>
          
          <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-1">
              <Droplets className="w-4 h-4 text-blue-300" />
              <span className="text-xs text-slate-400">Tide Anomaly</span>
            </div>
            <div className="text-xl font-bold text-white">{currentData.tideAnomaly}m</div>
          </div>
          
          <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-1">
              <Gauge className="w-4 h-4 text-purple-400" />
              <span className="text-xs text-slate-400">Pressure</span>
            </div>
            <div className="text-xl font-bold text-white">{currentData.pressure} hPa</div>
          </div>
          
          <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-1">
              <CloudRain className="w-4 h-4 text-indigo-400" />
              <span className="text-xs text-slate-400">Rainfall</span>
            </div>
            <div className="text-xl font-bold text-white">{currentData.rainfall} mm</div>
          </div>
          
          <div className={`rounded-lg p-3 border ${getStormAlertBg(currentData.stormIndex)}`}>
            <div className="flex items-center gap-2 mb-1">
              <Activity className={`w-4 h-4 ${getStormAlertColor(currentData.stormIndex)}`} />
              <span className="text-xs text-slate-400">Storm Index</span>
            </div>
            <div className={`text-xl font-bold ${getStormAlertColor(currentData.stormIndex)}`}>
              {currentData.stormIndex}
            </div>
          </div>
        </div>
      )}

      {/* Storm Index Chart */}
      <div className="mt-4">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Storm Index Trend (24h)
        </div>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="stormGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis 
                dataKey="time" 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: '1px solid #06b6d4',
                  borderRadius: '8px',
                }}
                labelStyle={{ color: '#94a3b8' }}
              />
              <Area
                type="monotone"
                dataKey="stormIndex"
                stroke="#f97316"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#stormGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Multi-metric Chart */}
      <div className="mt-4">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Environmental Parameters
        </div>
        <div className="h-32">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis 
                dataKey="time" 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: '1px solid #06b6d4',
                  borderRadius: '8px',
                }}
                labelStyle={{ color: '#94a3b8' }}
              />
              <Legend wrapperStyle={{ fontSize: '10px' }} />
              <Line
                type="monotone"
                dataKey="waveHeight"
                name="Wave (m)"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="windSpeed"
                name="Wind (km/h)"
                stroke="#06b6d4"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="tideAnomaly"
                name="Tide (m)"
                stroke="#8b5cf6"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Data Source */}
      <div className="mt-4 text-xs text-slate-500 text-center">
        Data sources: IMD Weather API, INCOIS Wave & Tide Data
      </div>
    </motion.div>
  );
};
