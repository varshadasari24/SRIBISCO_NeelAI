import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, 
  Bell, 
  MapPin, 
  Users, 
  Clock, 
  Phone, 
  Send,
  X,
  CheckCircle,
  Radio
} from 'lucide-react';
import type { SOSAlert, RiskLevel } from '@/types';
import { useState } from 'react';

interface SOSPanelProps {
  activeAlerts: SOSAlert[];
  nearbyDevices: { id: string; distance: number }[];
  onTriggerSOS: (type: 'flood' | 'erosion' | 'storm', severity: RiskLevel) => void;
  onDismissAlert: (alertId: string) => void;
  onClearAll: () => void;
  notificationPermission: NotificationPermission;
  onRequestPermission: () => void;
}

const getAlertColor = (severity: RiskLevel) => {
  switch (severity) {
    case 'critical':
      return 'bg-red-500/20 border-red-500/50 text-red-400';
    case 'high':
      return 'bg-orange-500/20 border-orange-500/50 text-orange-400';
    case 'moderate':
      return 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400';
    default:
      return 'bg-green-500/20 border-green-500/50 text-green-400';
  }
};

const getAlertIcon = (type: string) => {
  switch (type) {
    case 'flood':
      return <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center"><span className="text-lg">🌊</span></div>;
    case 'erosion':
      return <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center"><span className="text-lg">🏔️</span></div>;
    case 'storm':
      return <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center"><span className="text-lg">⛈️</span></div>;
    default:
      return <AlertTriangle className="w-8 h-8" />;
  }
};

export const SOSPanel = ({
  activeAlerts,
  nearbyDevices,
  onTriggerSOS,
  onDismissAlert,
  onClearAll,
  notificationPermission,
  onRequestPermission,
}: SOSPanelProps) => {
  const [selectedType, setSelectedType] = useState<'flood' | 'erosion' | 'storm'>('flood');
  const [selectedSeverity, setSelectedSeverity] = useState<RiskLevel>('high');

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <Radio className="w-5 h-5 animate-pulse" />
          SOS Broadcast System
        </h3>
        <div className="flex items-center gap-2">
          {activeAlerts.length > 0 && (
            <button
              onClick={onClearAll}
              className="text-xs text-slate-400 hover:text-white transition-colors"
            >
              Clear All
            </button>
          )}
          <div className="relative">
            <Bell className="w-5 h-5 text-cyan-400" />
            {activeAlerts.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center font-bold">
                {activeAlerts.length}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Notification Permission */}
      {notificationPermission !== 'granted' && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-yellow-200">Enable notifications for SOS alerts</span>
            </div>
            <button
              onClick={onRequestPermission}
              className="px-3 py-1 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 text-xs rounded-lg transition-colors"
            >
              Enable
            </button>
          </div>
        </motion.div>
      )}

      {/* SOS Trigger Form */}
      <div className="mb-4 p-4 bg-slate-800/50 rounded-lg border border-cyan-500/20">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-3">
          Manual SOS Trigger
        </div>
        
        <div className="space-y-3">
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Alert Type</label>
            <div className="grid grid-cols-3 gap-2">
              {(['flood', 'erosion', 'storm'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedType(type)}
                  className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                    selectedType === type
                      ? 'bg-cyan-500/30 text-cyan-400 border border-cyan-500/50'
                      : 'bg-slate-700/50 text-slate-400 border border-transparent hover:bg-slate-700'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 mb-1 block">Severity Level</label>
            <div className="grid grid-cols-4 gap-2">
              {(['low', 'moderate', 'high', 'critical'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setSelectedSeverity(level)}
                  className={`px-2 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                    selectedSeverity === level
                      ? level === 'critical'
                        ? 'bg-red-500/30 text-red-400 border border-red-500/50'
                        : level === 'high'
                        ? 'bg-orange-500/30 text-orange-400 border border-orange-500/50'
                        : level === 'moderate'
                        ? 'bg-yellow-500/30 text-yellow-400 border border-yellow-500/50'
                        : 'bg-green-500/30 text-green-400 border border-green-500/50'
                      : 'bg-slate-700/50 text-slate-400 border border-transparent hover:bg-slate-700'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => onTriggerSOS(selectedType, selectedSeverity)}
            className="w-full py-3 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-bold rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-red-500/30"
          >
            <Send className="w-4 h-4" />
            BROADCAST SOS ALERT
          </button>
        </div>
      </div>

      {/* Nearby Devices */}
      {nearbyDevices.length > 0 && (
        <div className="mb-4 p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-200">
                {nearbyDevices.length} devices within 500m
              </span>
            </div>
            <div className="text-xs text-cyan-400">
              Nearest: {Math.min(...nearbyDevices.map(d => d.distance))}m
            </div>
          </div>
        </div>
      )}

      {/* Active Alerts */}
      <div className="space-y-2 max-h-64 overflow-y-auto">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Active Alerts ({activeAlerts.length})
        </div>
        
        <AnimatePresence>
          {activeAlerts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-8 text-slate-500"
            >
              <CheckCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No active alerts</p>
              <p className="text-xs mt-1">System monitoring for emergencies</p>
            </motion.div>
          ) : (
            activeAlerts.map((alert) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className={`p-3 rounded-lg border ${getAlertColor(alert.severity)}`}
              >
                <div className="flex items-start gap-3">
                  {getAlertIcon(alert.type)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold uppercase text-sm">
                        {alert.type} Alert
                      </span>
                      <button
                        onClick={() => onDismissAlert(alert.id)}
                        className="text-slate-400 hover:text-white transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs mt-1 opacity-90 line-clamp-2">
                      {alert.message}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-[10px] opacity-70">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {alert.radius}m radius
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {alert.recipients} notified
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Emergency Contacts */}
      <div className="mt-4 pt-4 border-t border-slate-700">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Emergency Contacts
        </div>
        <div className="grid grid-cols-2 gap-2">
          <a
            href="tel:101"
            className="flex items-center gap-2 p-2 bg-red-500/10 border border-red-500/30 rounded-lg hover:bg-red-500/20 transition-colors"
          >
            <Phone className="w-4 h-4 text-red-400" />
            <div>
              <div className="text-xs font-bold text-red-400">Fire & Rescue</div>
              <div className="text-[10px] text-slate-400">101</div>
            </div>
          </a>
          <a
            href="tel:100"
            className="flex items-center gap-2 p-2 bg-blue-500/10 border border-blue-500/30 rounded-lg hover:bg-blue-500/20 transition-colors"
          >
            <Phone className="w-4 h-4 text-blue-400" />
            <div>
              <div className="text-xs font-bold text-blue-400">Police</div>
              <div className="text-[10px] text-slate-400">100</div>
            </div>
          </a>
        </div>
      </div>
    </motion.div>
  );
};
