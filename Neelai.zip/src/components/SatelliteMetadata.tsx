import { motion } from 'framer-motion';
import { 
  Satellite, 
  Cloud, 
  Calendar, 
  Maximize, 
  Activity,
  Download,
  Eye,
  Database
} from 'lucide-react';
import type { SatelliteData } from '@/types';
import { useState } from 'react';

interface SatelliteMetadataProps {
  satelliteData: SatelliteData[];
  latestScene: SatelliteData;
  isProcessing: boolean;
  onProcessMNDWI: () => void;
  onFetchLatest: () => void;
}

export const SatelliteMetadata = ({
  satelliteData,
  latestScene,
  isProcessing,
  onProcessMNDWI,
  onFetchLatest,
}: SatelliteMetadataProps) => {
  const [selectedScene, setSelectedScene] = useState<SatelliteData>(latestScene);

  const getCloudColor = (coverage: number) => {
    if (coverage < 10) return 'text-green-400';
    if (coverage < 20) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getErosionColor = (index: number) => {
    if (index < 0.5) return 'text-green-400';
    if (index < 0.7) return 'text-yellow-400';
    if (index < 0.85) return 'text-orange-400';
    return 'text-red-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <Satellite className="w-5 h-5" />
          Satellite Metadata
        </h3>
        <div className="flex items-center gap-2">
          <button
            onClick={onFetchLatest}
            className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 text-xs rounded-lg transition-colors flex items-center gap-1"
          >
            <Database className="w-3 h-3" />
            Fetch Latest
          </button>
          <button
            onClick={onProcessMNDWI}
            disabled={isProcessing}
            className="px-3 py-1.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 text-xs rounded-lg transition-colors flex items-center gap-1 disabled:opacity-50"
          >
            <Activity className="w-3 h-3" />
            {isProcessing ? 'Processing...' : 'Process MNDWI'}
          </button>
        </div>
      </div>

      {/* Latest Scene Info */}
      <div className="mb-4 p-4 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">
            Latest Scene
          </span>
          <span className="text-[10px] text-slate-400">
            {new Date(latestScene.timestamp).toLocaleString()}
          </span>
        </div>
        <div className="text-sm font-mono text-white mb-3 truncate">
          {latestScene.sceneId}
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Cloud className="w-3 h-3 text-slate-400" />
            </div>
            <div className={`text-lg font-bold ${getCloudColor(latestScene.cloudCoverage)}`}>
              {latestScene.cloudCoverage}%
            </div>
            <div className="text-[10px] text-slate-500">Cloud Cover</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Maximize className="w-3 h-3 text-slate-400" />
            </div>
            <div className="text-lg font-bold text-cyan-400">
              {latestScene.resolution}m
            </div>
            <div className="text-[10px] text-slate-500">Resolution</div>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Activity className="w-3 h-3 text-slate-400" />
            </div>
            <div className={`text-lg font-bold ${getErosionColor(latestScene.erosionIndex)}`}>
              {(latestScene.erosionIndex * 100).toFixed(0)}%
            </div>
            <div className="text-[10px] text-slate-500">Erosion Index</div>
          </div>
        </div>
      </div>

      {/* Processing Pipeline */}
      {isProcessing && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-4 p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg"
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-sm text-purple-400">Processing Pipeline</span>
          </div>
          <div className="space-y-1 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Fetching Sentinel-2 scene...</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Computing MNDWI...</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
              <span>Applying Otsu threshold...</span>
            </div>
            <div className="flex items-center gap-2 opacity-50">
              <div className="w-2 h-2 bg-slate-600 rounded-full"></div>
              <span>Running marching squares...</span>
            </div>
            <div className="flex items-center gap-2 opacity-50">
              <div className="w-2 h-2 bg-slate-600 rounded-full"></div>
              <span>Tidal correction (FES2014)...</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Scene History */}
      <div>
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Recent Scenes
        </div>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {satelliteData.map((scene, index) => (
            <motion.div
              key={scene.sceneId}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => setSelectedScene(scene)}
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                selectedScene.sceneId === scene.sceneId
                  ? 'bg-cyan-500/20 border-cyan-500/50'
                  : 'bg-slate-800/50 border-slate-700 hover:border-cyan-500/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-mono text-slate-300 truncate">
                    {scene.sceneId}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(scene.timestamp).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Cloud className="w-3 h-3" />
                      {scene.cloudCoverage}%
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-bold ${getErosionColor(scene.erosionIndex)}`}>
                    {(scene.erosionIndex * 100).toFixed(0)}%
                  </span>
                  <button className="p-1.5 bg-slate-700/50 hover:bg-slate-700 rounded transition-colors">
                    <Eye className="w-3 h-3 text-slate-400" />
                  </button>
                  <button className="p-1.5 bg-slate-700/50 hover:bg-slate-700 rounded transition-colors">
                    <Download className="w-3 h-3 text-slate-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Data Source */}
      <div className="mt-4 text-xs text-slate-500 text-center">
        Sources: Sentinel-2 MSI, Sentinel-1 SAR, Landsat 8/9, Google Earth Engine
      </div>
    </motion.div>
  );
};
