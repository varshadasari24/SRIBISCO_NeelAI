import { motion } from 'framer-motion';
import { TrendingDown, Calendar, Activity, BarChart3 } from 'lucide-react';
import type { ShorelinePoint } from '@/types';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';

interface ErosionTrendProps {
  historicalData: ShorelinePoint[];
  futurePredictions: ShorelinePoint[];
  epr: number;
  lrr: number;
  fractalDimension: number;
}

export const ErosionTrend = ({
  historicalData,
  futurePredictions,
  epr,
  lrr,
  fractalDimension,
}: ErosionTrendProps) => {
  // Combine historical and future data
  const allData = [
    ...historicalData.map(d => ({ ...d, type: 'historical' })),
    ...futurePredictions.map(d => ({ ...d, type: 'predicted' })),
  ];

  const chartData = allData.map((d) => ({
    year: d.year,
    deviation: Math.abs(d.deviation),
    type: d.type,
  }));

  const currentDeviation = Math.abs(historicalData[historicalData.length - 1]?.deviation || 0);
  const predicted2100 = Math.abs(futurePredictions.find(d => d.year === 2100)?.deviation || 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <TrendingDown className="w-5 h-5" />
          Shoreline Erosion Trends
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-1 bg-red-500/20 text-red-400 rounded-full">
            EPR: {epr} m/yr
          </span>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
          <div className="flex items-center gap-2 mb-1">
            <Activity className="w-4 h-4 text-red-400" />
            <span className="text-xs text-slate-400">EPR Rate</span>
          </div>
          <div className="text-xl font-bold text-red-400">{epr} m/yr</div>
          <div className="text-[10px] text-slate-500">End Point Rate</div>
        </div>
        
        <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-4 h-4 text-orange-400" />
            <span className="text-xs text-slate-400">LRR Rate</span>
          </div>
          <div className="text-xl font-bold text-orange-400">{lrr} m/yr</div>
          <div className="text-[10px] text-slate-500">Linear Regression</div>
        </div>
        
        <div className="bg-slate-800/50 rounded-lg p-3 border border-cyan-500/20">
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-slate-400">Fractal Dim.</span>
          </div>
          <div className="text-xl font-bold text-purple-400">{fractalDimension}</div>
          <div className="text-[10px] text-slate-500">Complexity Index</div>
        </div>
      </div>

      {/* Deviation Stats */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
          <div className="text-xs text-red-400 mb-1">Current Deviation (2025)</div>
          <div className="text-2xl font-bold text-red-400">{currentDeviation.toFixed(1)}m</div>
          <div className="text-[10px] text-slate-500">Land lost to sea</div>
        </div>
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-3">
          <div className="text-xs text-purple-400 mb-1">Predicted (2100)</div>
          <div className="text-2xl font-bold text-purple-400">{predicted2100.toFixed(0)}m</div>
          <div className="text-[10px] text-slate-500">100-year forecast</div>
        </div>
      </div>

      {/* Erosion Timeline Chart */}
      <div className="mt-4">
        <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-2">
          Shoreline Deviation Timeline (1910-2125)
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="historicalGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis 
                dataKey="year" 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
                interval={4}
              />
              <YAxis 
                stroke="#64748b" 
                fontSize={10}
                tickLine={false}
                label={{ value: 'Deviation (m)', angle: -90, position: 'insideLeft', style: { fill: '#64748b', fontSize: 10 } }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: '1px solid #06b6d4',
                  borderRadius: '8px',
                }}
                labelStyle={{ color: '#94a3b8' }}
                formatter={(value: number) => [`${value.toFixed(1)}m`, 'Deviation']}
              />
              <ReferenceLine x={2025} stroke="#f97316" strokeDasharray="3 3" label={{ value: 'Now', fill: '#f97316', fontSize: 10 }} />
              <Area
                type="monotone"
                dataKey="deviation"
                stroke="#06b6d4"
                strokeWidth={2}
                fill="url(#historicalGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-3 flex items-center justify-center gap-6 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-cyan-500"></div>
          <span className="text-slate-400">Historical Data</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-purple-500"></div>
          <span className="text-slate-400">AI Prediction</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-1 bg-orange-500"></div>
          <span className="text-slate-400">Current</span>
        </div>
      </div>

      {/* Data Source */}
      <div className="mt-4 text-xs text-slate-500 text-center">
        Sources: NCCR Shoreline Atlas, Landsat/Sentinel Archive, ISRO Bhuvan
      </div>
    </motion.div>
  );
};
