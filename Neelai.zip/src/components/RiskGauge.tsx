import { motion } from 'framer-motion';
import { AlertTriangle, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { RiskScore } from '@/types';
import { getRiskColor, getRiskGradient } from '@/hooks/useRiskFusion';

interface RiskGaugeProps {
  riskScore: RiskScore | null;
  riskTrend: 'increasing' | 'decreasing' | 'stable';
}

export const RiskGauge = ({ riskScore, riskTrend }: RiskGaugeProps) => {
  const score = riskScore?.score || 0;
  const level = riskScore?.level || 'low';
  const color = getRiskColor(level);
  const gradient = getRiskGradient(level);
  
  // Calculate gauge rotation (0-180 degrees)
  const gaugeRotation = Math.min(score * 180, 180);
  
  const getTrendIcon = () => {
    switch (riskTrend) {
      case 'increasing':
        return <TrendingUp className="w-5 h-5 text-red-400" />;
      case 'decreasing':
        return <TrendingDown className="w-5 h-5 text-green-400" />;
      default:
        return <Minus className="w-5 h-5 text-slate-400" />;
    }
  };

  const getRiskLabel = () => {
    switch (level) {
      case 'low':
        return 'LOW RISK';
      case 'moderate':
        return 'MODERATE RISK';
      case 'high':
        return 'HIGH RISK';
      case 'critical':
        return 'CRITICAL RISK';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" />
          Real-Time Risk Score
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Trend:</span>
          {getTrendIcon()}
        </div>
      </div>

      {/* Gauge Container */}
      <div className="relative flex flex-col items-center">
        {/* Gauge Background */}
        <div className="relative w-48 h-24 overflow-hidden">
          {/* Background Arc */}
          <div className="absolute inset-0 rounded-t-full bg-slate-800/50 border-4 border-slate-700"></div>
          
          {/* Colored Arc */}
          <motion.div
            className={`absolute inset-0 rounded-t-full bg-gradient-to-r ${gradient} opacity-80`}
            initial={{ opacity: 0 }}
            animate={{ opacity: score > 0 ? 0.8 : 0 }}
            transition={{ duration: 0.5 }}
            style={{
              clipPath: `polygon(0 100%, 0 0, ${gaugeRotation / 1.8}% 0, ${gaugeRotation / 1.8}% 100%)`,
            }}
          />
          
          {/* Gauge Needle */}
          <motion.div
            className="absolute bottom-0 left-1/2 w-1 h-20 origin-bottom"
            initial={{ rotate: -90 }}
            animate={{ rotate: -90 + gaugeRotation }}
            transition={{ type: 'spring', stiffness: 60, damping: 15 }}
            style={{ marginLeft: '-2px' }}
          >
            <div className="w-full h-full bg-gradient-to-t from-white to-cyan-400 rounded-full shadow-lg shadow-cyan-500/50"></div>
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-white rounded-full shadow-lg"></div>
          </motion.div>
          
          {/* Center Cover */}
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-8 h-8 bg-slate-900 rounded-full border-2 border-cyan-500/50 flex items-center justify-center">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
          </div>
        </div>

        {/* Score Display */}
        <motion.div
          className="mt-4 text-center"
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200 }}
        >
          <div 
            className="text-5xl font-black tracking-tighter"
            style={{ color }}
          >
            {(score * 100).toFixed(1)}%
          </div>
          <div 
            className="text-lg font-bold mt-1 uppercase tracking-wider"
            style={{ color }}
          >
            {getRiskLabel()}
          </div>
        </motion.div>

        {/* Risk Factors */}
        {riskScore?.factors && (
          <div className="mt-4 w-full space-y-2">
            <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Risk Factors</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between items-center bg-slate-800/50 rounded px-2 py-1">
                <span className="text-slate-400">Shoreline Dev.</span>
                <span className="text-cyan-400">{(riskScore.factors.shorelineDeviation * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between items-center bg-slate-800/50 rounded px-2 py-1">
                <span className="text-slate-400">Storm Index</span>
                <span className="text-cyan-400">{(riskScore.factors.stormIndex * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between items-center bg-slate-800/50 rounded px-2 py-1">
                <span className="text-slate-400">Environment</span>
                <span className="text-cyan-400">{(riskScore.factors.environmentalAnomaly * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between items-center bg-slate-800/50 rounded px-2 py-1">
                <span className="text-slate-400">Proximity</span>
                <span className="text-cyan-400">{(riskScore.factors.proximityToCoast * 100).toFixed(0)}%</span>
              </div>
            </div>
          </div>
        )}

        {/* Threshold Indicators */}
        <div className="mt-4 w-full flex justify-between text-[10px] text-slate-500">
          <span>0%</span>
          <span className="text-green-500">40%</span>
          <span className="text-yellow-500">65%</span>
          <span className="text-orange-500">85%</span>
          <span className="text-red-500">100%</span>
        </div>
      </div>

      {/* Last Update */}
      <div className="mt-4 text-center text-xs text-slate-500">
        Last updated: {new Date(riskScore?.timestamp || Date.now()).toLocaleTimeString()}
      </div>
    </motion.div>
  );
};
