import { motion } from 'framer-motion';
import { 
  Cpu, 
  MapPin, 
  Satellite, 
  Cloud, 
  Activity, 
  Bell,
  Calendar,
  CheckCircle,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { useState, useEffect } from 'react';

interface Agent {
  id: string;
  name: string;
  icon: React.ReactNode;
  status: 'active' | 'inactive' | 'error';
  lastUpdate: number;
  interval: number;
  description: string;
}

export const AgentStatus = () => {
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: 'geo',
      name: 'Geo-Intelligence Agent',
      icon: <MapPin className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 60,
      description: 'GPS tracking & geofencing',
    },
    {
      id: 'satellite',
      name: 'Satellite Shoreline Agent',
      icon: <Satellite className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 86400,
      description: 'MNDWI processing & shoreline extraction',
    },
    {
      id: 'environmental',
      name: 'Environmental Data Agent',
      icon: <Cloud className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 300,
      description: 'IMD/INCOIS API polling',
    },
    {
      id: 'risk',
      name: 'Risk Fusion Agent',
      icon: <Activity className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 60,
      description: 'Risk score computation',
    },
    {
      id: 'response',
      name: 'Autonomous Response Agent',
      icon: <Bell className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 10,
      description: 'SOS alerts & notifications',
    },
    {
      id: 'forecast',
      name: 'Long-Term Forecast Agent',
      icon: <Calendar className="w-4 h-4" />,
      status: 'active',
      lastUpdate: Date.now(),
      interval: 604800,
      description: '100-year shoreline prediction',
    },
  ]);

  const [systemHealth] = useState(98);

  // Simulate agent updates
  useEffect(() => {
    const interval = setInterval(() => {
      setAgents((prev) =>
        prev.map((agent) => ({
          ...agent,
          lastUpdate: Date.now(),
        }))
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-green-400 bg-green-500/20 border-green-500/50';
      case 'inactive':
        return 'text-slate-400 bg-slate-500/20 border-slate-500/50';
      case 'error':
        return 'text-red-400 bg-red-500/20 border-red-500/50';
      default:
        return 'text-slate-400 bg-slate-500/20 border-slate-500/50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-3 h-3" />;
      case 'inactive':
        return <RefreshCw className="w-3 h-3" />;
      case 'error':
        return <AlertCircle className="w-3 h-3" />;
      default:
        return <RefreshCw className="w-3 h-3" />;
    }
  };

  const formatInterval = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
  };

  const activeAgents = agents.filter((a) => a.status === 'active').length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl p-6 border border-cyan-500/30 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center gap-2">
          <Cpu className="w-5 h-5" />
          Agentic AI Orchestration
        </h3>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-slate-400">System Health</div>
            <div className={`text-lg font-bold ${systemHealth > 90 ? 'text-green-400' : systemHealth > 70 ? 'text-yellow-400' : 'text-red-400'}`}>
              {systemHealth}%
            </div>
          </div>
          <div className="w-12 h-12 rounded-full border-4 border-slate-700 flex items-center justify-center">
            <div className={`text-xs font-bold ${activeAgents === agents.length ? 'text-green-400' : 'text-yellow-400'}`}>
              {activeAgents}/{agents.length}
            </div>
          </div>
        </div>
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 gap-2">
        {agents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-3 rounded-lg border ${getStatusColor(agent.status)} transition-all`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center">
                  {agent.icon}
                </div>
                <div>
                  <div className="text-sm font-semibold">{agent.name}</div>
                  <div className="text-[10px] opacity-70">{agent.description}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-xs">
                  {getStatusIcon(agent.status)}
                  <span className="capitalize">{agent.status}</span>
                </div>
                <div className="text-[10px] opacity-70">
                  Interval: {formatInterval(agent.interval)}
                </div>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-current"
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{
                  duration: agent.interval,
                  repeat: Infinity,
                  ease: 'linear',
                }}
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* System Metrics */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        <div className="bg-slate-800/50 rounded-lg p-3 text-center border border-slate-700">
          <div className="text-2xl font-bold text-cyan-400">{activeAgents}</div>
          <div className="text-[10px] text-slate-400">Active Agents</div>
        </div>
        <div className="bg-slate-800/50 rounded-lg p-3 text-center border border-slate-700">
          <div className="text-2xl font-bold text-green-400">0</div>
          <div className="text-[10px] text-slate-400">Errors</div>
        </div>
        <div className="bg-slate-800/50 rounded-lg p-3 text-center border border-slate-700">
          <div className="text-2xl font-bold text-purple-400">24ms</div>
          <div className="text-[10px] text-slate-400">Avg Latency</div>
        </div>
      </div>

      {/* Architecture Note */}
      <div className="mt-4 p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
        <div className="text-xs text-cyan-300">
          <strong>n8n-style Workflow Orchestration</strong>
          <p className="mt-1 opacity-80">
            Agents trigger in sequence based on data dependencies. 
            Risk Fusion waits for Geo + Environmental + Satellite data.
          </p>
        </div>
      </div>
    </motion.div>
  );
};
