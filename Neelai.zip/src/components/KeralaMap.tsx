import { useEffect } from 'react';
import { MapContainer, TileLayer, GeoJSON, Circle, Marker, Popup, useMap } from 'react-leaflet';
import { DivIcon } from 'leaflet';
import { motion } from 'framer-motion';
import { Navigation, AlertTriangle, Waves, Wind, Droplets } from 'lucide-react';
import type { GeoFence, UserLocation, SOSAlert, NearbyDevice } from '@/types';
import 'leaflet/dist/leaflet.css';

// Kerala coastline GeoJSON (simplified)
const KERALA_COASTLINE = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      properties: { name: 'Kerala Coast' },
      geometry: {
        type: 'LineString',
        coordinates: [
          [74.9, 12.6], [75.0, 12.5], [75.1, 12.3], [75.2, 12.1], [75.3, 11.9],
          [75.4, 11.7], [75.5, 11.5], [75.6, 11.3], [75.7, 11.1], [75.8, 10.9],
          [75.9, 10.7], [76.0, 10.5], [76.1, 10.3], [76.2, 10.1], [76.3, 9.9],
          [76.4, 9.7], [76.3, 9.5], [76.2, 9.3], [76.1, 9.1], [76.0, 8.9],
          [75.9, 8.7], [75.8, 8.5], [75.7, 8.3], [75.6, 8.1],
        ],
      },
    },
  ],
};

// District boundaries
const DISTRICTS = [
  { name: 'Kasaragod', center: [12.5, 75.0], risk: 'moderate' },
  { name: 'Kannur', center: [11.9, 75.4], risk: 'moderate' },
  { name: 'Kozhikode', center: [11.25, 75.8], risk: 'high' },
  { name: 'Malappuram', center: [11.05, 76.1], risk: 'moderate' },
  { name: 'Thrissur', center: [10.5, 76.2], risk: 'low' },
  { name: 'Ernakulam', center: [10.0, 76.3], risk: 'moderate' },
  { name: 'Alappuzha', center: [9.5, 76.3], risk: 'critical' },
  { name: 'Kottayam', center: [9.6, 76.5], risk: 'low' },
  { name: 'Pathanamthitta', center: [9.3, 76.8], risk: 'low' },
  { name: 'Kollam', center: [8.9, 76.6], risk: 'moderate' },
  { name: 'Thiruvananthapuram', center: [8.5, 76.9], risk: 'high' },
];

// Risk zone colors
const RISK_COLORS = {
  low: '#22c55e',
  moderate: '#eab308',
  high: '#f97316',
  critical: '#ef4444',
};

// Custom user location icon
const userLocationIcon = new DivIcon({
  className: 'custom-user-marker',
  html: `
    <div class="relative">
      <div class="absolute inset-0 bg-cyan-500 rounded-full animate-ping opacity-75"></div>
      <div class="relative w-4 h-4 bg-cyan-400 rounded-full border-2 border-white shadow-lg shadow-cyan-500/50"></div>
    </div>
  `,
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

// SOS alert icon
const sosAlertIcon = new DivIcon({
  className: 'custom-sos-marker',
  html: `
    <div class="relative">
      <div class="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-75"></div>
      <div class="relative w-6 h-6 bg-red-500 rounded-full border-2 border-white shadow-lg shadow-red-500/50 flex items-center justify-center">
        <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
      </div>
    </div>
  `,
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

// Nearby device icon
const deviceIcon = new DivIcon({
  className: 'custom-device-marker',
  html: `
    <div class="w-3 h-3 bg-blue-400 rounded-full border border-white shadow-lg opacity-70"></div>
  `,
  iconSize: [12, 12],
  iconAnchor: [6, 6],
});

interface MapControllerProps {
  center: [number, number];
  zoom: number;
}

const MapController = ({ center, zoom }: MapControllerProps) => {
  const map = useMap();
  
  useEffect(() => {
    map.setView(center, zoom);
  }, [map, center, zoom]);
  
  return null;
};

interface KeralaMapProps {
  userLocation: UserLocation | null;
  geofences: GeoFence[];
  activeAlerts: SOSAlert[];
  nearbyDevices: NearbyDevice[];
  showSatellite: boolean;
  showRiskHeatmap: boolean;
  showShoreline: boolean;
}

export const KeralaMap = ({
  userLocation,
  geofences,
  activeAlerts,
  nearbyDevices,
  showSatellite,
  showRiskHeatmap,
  showShoreline,
}: KeralaMapProps) => {
  const mapCenter: [number, number] = userLocation
    ? [userLocation.lat, userLocation.lng]
    : [9.98, 76.27]; // Default to Ernakulam

  const mapZoom = userLocation ? 12 : 9;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="relative w-full h-full rounded-xl overflow-hidden border border-cyan-500/30 shadow-2xl shadow-cyan-900/20"
    >
      <MapContainer
        center={mapCenter}
        zoom={mapZoom}
        className="w-full h-full"
        zoomControl={false}
      >
        <MapController center={mapCenter} zoom={mapZoom} />
        
        {/* Base Map Layer */}
        {showSatellite ? (
          <TileLayer
            attribution='&copy; <a href="https://www.esri.com">Esri</a>'
            url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
          />
        ) : (
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          />
        )}

        {/* Kerala Coastline */}
        {showShoreline && (
          <GeoJSON
            data={KERALA_COASTLINE as any}
            style={{
              color: '#06b6d4',
              weight: 3,
              opacity: 0.8,
              dashArray: '5, 10',
            }}
          />
        )}

        {/* District Risk Zones */}
        {showRiskHeatmap && DISTRICTS.map((district) => (
          <Circle
            key={district.name}
            center={district.center as [number, number]}
            radius={15000}
            pathOptions={{
              fillColor: RISK_COLORS[district.risk as keyof typeof RISK_COLORS],
              fillOpacity: 0.3,
              color: RISK_COLORS[district.risk as keyof typeof RISK_COLORS],
              weight: 1,
            }}
          >
            <Popup>
              <div className="text-slate-900">
                <strong>{district.name}</strong>
                <br />
                Risk Level: <span className="capitalize">{district.risk}</span>
              </div>
            </Popup>
          </Circle>
        ))}

        {/* Geofence Zones */}
        {geofences.map((fence) => (
          <Circle
            key={fence.id}
            center={fence.center}
            radius={fence.radius}
            pathOptions={{
              fillColor: RISK_COLORS[fence.riskLevel],
              fillOpacity: 0.2,
              color: RISK_COLORS[fence.riskLevel],
              weight: 2,
              dashArray: '5, 5',
            }}
          >
            <Popup>
              <div className="text-slate-900">
                <strong>Geofence: {fence.id}</strong>
                <br />
                Type: <span className="capitalize">{fence.type}</span>
                <br />
                Risk: <span className="capitalize">{fence.riskLevel}</span>
              </div>
            </Popup>
          </Circle>
        ))}

        {/* User Location */}
        {userLocation && (
          <Marker
            position={[userLocation.lat, userLocation.lng]}
            icon={userLocationIcon}
          >
            <Popup>
              <div className="text-slate-900">
                <strong>Your Location</strong>
                <br />
                Lat: {userLocation.lat.toFixed(4)}
                <br />
                Lng: {userLocation.lng.toFixed(4)}
                <br />
                Accuracy: {userLocation.accuracy?.toFixed(0)}m
              </div>
            </Popup>
          </Marker>
        )}

        {/* Active SOS Alerts */}
        {activeAlerts.map((alert) => (
          <Marker
            key={alert.id}
            position={[alert.location.lat, alert.location.lng]}
            icon={sosAlertIcon}
          >
            <Popup>
              <div className="text-slate-900 max-w-xs">
                <div className="flex items-center gap-2 text-red-600 font-bold mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="uppercase">{alert.type} ALERT</span>
                </div>
                <p className="text-sm">{alert.message}</p>
                <div className="mt-2 text-xs text-slate-500">
                  Radius: {alert.radius}m | Recipients: {alert.recipients}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Nearby Devices */}
        {nearbyDevices.map((device) => (
          <Marker
            key={device.id}
            position={device.location}
            icon={deviceIcon}
          >
            <Popup>
              <div className="text-slate-900 text-xs">
                <strong>Nearby Device</strong>
                <br />
                Distance: {device.distance}m
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Map Overlay Controls */}
      <div className="absolute bottom-4 left-4 flex flex-col gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md rounded-lg p-3 border border-cyan-500/30">
          <div className="text-xs text-cyan-400 font-semibold mb-2">MAP LEGEND</div>
          <div className="space-y-1.5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-cyan-400 border border-white"></div>
              <span>Your Location</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500 border border-white"></div>
              <span>SOS Alert</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-400 opacity-70"></div>
              <span>Nearby Device</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span>Low Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <span>Moderate Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-orange-500"></div>
              <span>High Risk</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span>Critical Risk</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Overlay */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md rounded-lg p-3 border border-cyan-500/30">
          <div className="text-xs text-cyan-400 font-semibold mb-2">LIVE METRICS</div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2">
              <Waves className="w-4 h-4 text-blue-400" />
              <div>
                <div className="text-[10px] text-slate-400">Wave Height</div>
                <div className="text-sm font-bold text-white">2.8m</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-cyan-400" />
              <div>
                <div className="text-[10px] text-slate-400">Wind Speed</div>
                <div className="text-sm font-bold text-white">18 km/h</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Droplets className="w-4 h-4 text-blue-300" />
              <div>
                <div className="text-[10px] text-slate-400">Tide</div>
                <div className="text-sm font-bold text-white">1.4m</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-green-400" />
              <div>
                <div className="text-[10px] text-slate-400">Distance to Coast</div>
                <div className="text-sm font-bold text-white">2.3 km</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
