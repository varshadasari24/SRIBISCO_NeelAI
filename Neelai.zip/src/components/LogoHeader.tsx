import { motion } from 'framer-motion';

export const LogoHeader = () => {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="w-full bg-gradient-to-b from-slate-950/90 to-slate-900/80 backdrop-blur-xl border-b border-cyan-500/20 py-4 px-6"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Left Logo - Disaster Management */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="flex-shrink-0"
        >
          <img
            src="/logos/dm.png"
            alt="Kerala State Disaster Management Authority"
            className="h-16 w-auto object-contain drop-shadow-lg"
          />
        </motion.div>

        {/* Center - Malayalam Logos Side by Side */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="flex items-center gap-4"
        >
          <img
            src="/logos/logo.png"
            alt="നീലൈ"
            className="h-14 w-auto object-contain drop-shadow-lg"
          />
          <img
            src="/logos/logo2.png"
            alt="നീലൈ"
            className="h-14 w-auto object-contain drop-shadow-lg"
          />
        </motion.div>

        {/* Right Logo - SRIBISCO */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="flex-shrink-0"
        >
          <img
            src="/logos/teamlogo.jpeg"
            alt="SRIBISCO"
            className="h-16 w-auto object-contain drop-shadow-lg rounded-lg"
          />
        </motion.div>
      </div>

      {/* Title Bar */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="max-w-7xl mx-auto mt-3 text-center"
      >
        <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent tracking-wide">
          NEELAI — Neural Environmental & Erosion Learning AI
        </h1>
        <p className="text-cyan-300/70 text-sm mt-1 tracking-wider uppercase">
          India's First Agentic Coastal Disaster Intelligence System
        </p>
      </motion.div>
    </motion.header>
  );
};
